"""Validate the public Arcadia catalog and require built-in game modules."""
import json
import re
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / 'catalog.json').read_text())
assert isinstance(data, list), 'catalog.json must be a list'
ids = set()
for game in data:
    assert isinstance(game, dict), 'Each game must be an object'
    identifier = game['id']
    assert isinstance(identifier, str) and re.fullmatch(r'[a-z0-9-]+', identifier), 'Invalid game id'
    assert identifier not in ids, 'Duplicate game id'
    ids.add(identifier)
    assert isinstance(game.get('title'), str) and 0 < len(game['title']) <= 70
    assert isinstance(game.get('description'), str) and len(game['description']) <= 240
    assert isinstance(game.get('category'), str) and game['category']
    assert isinstance(game.get('accent'), str) and re.fullmatch(r'#[0-9a-fA-F]{6}', game['accent'])
    if game.get('type') == 'built-in':
        assert (ROOT / 'games' / f'{identifier}.js').is_file(), f'Missing game module: {identifier}'
    else:
        assert game.get('type') == 'external'
        assert isinstance(game.get('url'), str) and game['url'].startswith('https://')
print(f'Validated {len(data)} catalog games.')
