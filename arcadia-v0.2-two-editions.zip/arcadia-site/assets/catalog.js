window.Arcadia={
async catalog(){let base=[];try{const r=await fetch('catalog.json',{cache:'no-store'});if(!r.ok)throw Error();base=await r.json()}catch(e){base=[]}let local=null;try{local=JSON.parse(localStorage.getItem('arcadia-catalog'))}catch(e){}return Array.isArray(local)?local:base},
async published(){let r=await fetch('catalog.json',{cache:'no-store'});if(!r.ok)throw Error('Could not load published catalog');return await r.json()},
getFavorites(){try{return JSON.parse(localStorage.getItem('arcadia-favorites'))||[]}catch(e){return []}},
toggleFavorite(id){const s=new Set(this.getFavorites());s.has(id)?s.delete(id):s.add(id);localStorage.setItem('arcadia-favorites',JSON.stringify([...s]));return s.has(id)},
escape(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))},
validGame(g){return g&&/^[a-z0-9-]+$/.test(g.id)&&typeof g.title==='string'&&g.title.length<=70&&g.title.length>0&&typeof g.description==='string'&&g.description.length<=240&&['built-in','external'].includes(g.type)&&(!g.url||/^https:\/\//.test(g.url))&&/^#[0-9a-f]{6}$/i.test(g.accent||'')}
};
